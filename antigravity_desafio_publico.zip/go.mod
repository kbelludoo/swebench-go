module example.com/prioritytrap

go 1.23
