package prioritytrap

import (
    "context"
    "errors"
)

// Priority identifies which input delivered an event.
type Priority uint8

const (
    High Priority = iota + 1
    Low
)

// Event is delivered synchronously to emit.
type Event struct {
    Priority Priority
    Value    int
}

var ErrNotImplemented = errors.New("TODO: implement Drain without modifying the tests")

// Drain must satisfy the contract in README.md. Implement it from scratch.
// The input channels may be closed or nil; emit is non-nil.
func Drain(ctx context.Context, high <-chan int, low <-chan int, emit func(Event)) error {
    return ErrNotImplemented
}
